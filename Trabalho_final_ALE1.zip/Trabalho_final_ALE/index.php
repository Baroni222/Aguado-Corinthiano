<?php
require 'conexao.php';
session_start();

// Variável para exibir mensagens ao usuário
$mensagem = "";

// Verificar se o formulário de registro foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registrar'])) {
    $usuario = $_POST['usuario'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Criptografar a senha

    try {
        $stmt = $pdo->prepare("INSERT INTO usuarios (usuario, senha) VALUES (:usuario, :senha)");
        $stmt->bindParam(':usuario', $usuario);
        $stmt->bindParam(':senha', $senha);
        $stmt->execute();

        $mensagem = "Conta criada com sucesso! Faça login.";
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            $mensagem = "O nome de usuário já está em uso.";
        } else {
            $mensagem = "Erro ao criar conta: " . $e->getMessage();
        }
    }
}

// Verificar se o formulário de login foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE usuario = :usuario");
    $stmt->bindParam(':usuario', $usuario);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($senha, $user['senha'])) {
        $_SESSION['usuario'] = $user['usuario'];
        
        // Redirecionar para index.html após login bem-sucedido
        header("Location: index.html");
        exit;
    } else {
        $mensagem = "Usuário ou senha incorretos.";
    }
}

// Verificar se o formulário de atualização de e-mail foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_email'])) {
    if (isset($_SESSION['usuario'])) {
        $email = $_POST['email'];
        $usuario = $_SESSION['usuario'];

        $stmt = $pdo->prepare("UPDATE usuarios SET email = :email WHERE usuario = :usuario");
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':usuario', $usuario);
        $stmt->execute();

        $mensagem = "E-mail atualizado com sucesso!";
    } else {
        $mensagem = "Você precisa estar logado para atualizar o e-mail.";
    }
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Login e Registro</title>
</head>
<body>
    <h1>Sistema de Login, Registro e Atualização de E-mail</h1>

    <!-- Exibir mensagem -->
    <?php if ($mensagem): ?>
        <p><?php echo $mensagem; ?></p>
    <?php endif; ?>

    <!-- Se o usuário não estiver logado -->
    <?php if (!isset($_SESSION['usuario'])): ?>
        <h2>Registrar</h2>
        <form method="POST" action="index.php">
            <label for="usuario">Usuário:</label>
            <input type="text" id="usuario" name="usuario" required><br>
            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required><br>
            <button type="submit" name="registrar">Registrar</button>
        </form>

        <h2>Login</h2>
        <form method="POST" action="index.php">
            <label for="usuario">Usuário:</label>
            <input type="text" id="usuario" name="usuario" required><br>
            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required><br>
            <button type="submit" name="login">Entrar</button>
        </form>
    <?php else: ?>
        <!-- Se o usuário estiver logado -->
        <h2>Atualizar E-mail</h2>
        <p>Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario']); ?>! <a href="index.php?logout=true">Sair</a></p>
        <form method="POST" action="index.php">
            <label for="email">Novo E-mail:</label>
            <input type="email" id="email" name="email" required><br>
            <button type="submit" name="atualizar_email">Atualizar</button>
        </form>
        
    <?php endif; ?>
</body>
</html>
