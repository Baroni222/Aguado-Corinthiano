<?php
require 'conexao.php';
session_start();

if (!isset($_SESSION['usuario'])) {
    die("Você precisa estar logado para acessar esta página. <a href='login.php'>Login</a>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $usuario = $_SESSION['usuario'];

    $stmt = $pdo->prepare("UPDATE usuarios SET email = :email WHERE usuario = :usuario");
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':usuario', $usuario);
    $stmt->execute();

    echo "E-mail atualizado com sucesso!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar E-mail</title>
</head>
<body>
    <h1>Atualizar E-mail</h1>
    <form method="POST" action="atualizar_email.php">
        <label for="email">Novo E-mail:</label>
        <input type="email" id="email" name="email" required><br>
        <button type="submit">Atualizar</button>
    </form>
</body>
</html>
